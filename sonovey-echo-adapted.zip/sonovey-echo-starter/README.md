# Sonovey Echo — service-adapted starter

This version is adapted to the services chosen for Sonovey Echo:

- **Vercel** — static website and serverless API
- **Airtable** — public catalog metadata
- **Filebase** — planned object storage for uploaded audio, video, and artwork

## Airtable base already created

- Base name: `Sonovey Echo`
- Base ID: `appbrRoPiqiN2GUva`
- Media table: `Media`
- Table ID: `tblQO2Ee70tX0izBw`

The API defaults to these IDs, but environment variables can override them.

### Required Airtable fields

| Field | Type | Purpose |
|---|---|---|
| `Title` | Single line text (primary field) | Media title |
| `Creator` | Single line text | Artist / creator |
| `Type` | Single select: `audio`, `video` | Media type |
| `MediaURL` | URL | Publicly playable direct media URL |
| `ArtworkURL` | URL | Optional cover art |
| `Album` | Single line text | Optional album name |
| `Published` | Checkbox | Must be checked for public catalog visibility |

The catalog endpoint filters for `{Published}=1`. It returns only published records.

## Deploy on Vercel

1. Extract this ZIP.
2. Put the files in a Git repository and import that repository into Vercel.
3. In the Vercel project, open **Settings → Environment Variables**.
4. Add the variables below, then redeploy.

| Variable | Value |
|---|---|
| `AIRTABLE_TOKEN` | Your Airtable personal access token (secret) |
| `AIRTABLE_BASE_ID` | `appbrRoPiqiN2GUva` |
| `AIRTABLE_MEDIA_TABLE` | `tblQO2Ee70tX0izBw` |
| `AIRTABLE_SORT_FIELD` | `Title` |

Create the Airtable token at https://airtable.com/create/tokens. Grant access only to the Sonovey Echo base and only the record-read permission needed for the current catalog endpoint. Do not paste the token into chat, source files, Git, or frontend JavaScript.

After deployment, test `/api/catalog`. If there are no published rows, the API should return an empty `records` array.

## Filebase integration

Use the existing Filebase account for media objects. Its S3-compatible endpoint is `https://s3.filebase.io`.

**Important:** actual upload support is not enabled in this starter yet. It needs authenticated creator sessions and server-side/presigned upload authorization first. Do not create a public upload endpoint that lets anyone consume the storage quota.

When adding the upload backend, store Filebase credentials only in Vercel environment variables, such as:

- `FILEBASE_ACCESS_KEY`
- `FILEBASE_SECRET_KEY`
- `FILEBASE_BUCKET`
- `FILEBASE_ENDPOINT` = `https://s3.filebase.io`
- `FILEBASE_REGION` = `us-east-1` (confirm the value supported by your Filebase S3 configuration)

These are configuration names only. Fill them in with credentials from your own Filebase account; do not invent values or expose them to the browser.

A later authenticated upload flow should:
1. Verify the signed-in creator and their permission to upload.
2. Issue a short-lived presigned upload URL or proxy the upload server-side.
3. Upload the media object to Filebase.
4. Save its media URL/key and metadata in Airtable.
5. Publish the record only when the creator chooses to publish.

## Player features currently included

- Responsive dark interface
- Local audio and video playback from a device file picker
- Direct HTTP(S) audio/video URL playback
- Shareable `?q=` URL support
- Catalog search and Audio/Video filters
- Airtable catalog reads through the Vercel API

Example share link:

`https://YOUR-VERCEL-DOMAIN.vercel.app/?q=https%3A%2F%2Fexample.com%2Ftrack.mp3`

Local `blob:` URLs only work on the device that selected the file and cannot be shared. Browser support, CORS, and media hosting rules can affect whether remote media plays.

## Not included yet

- Creator sign-up/sign-in
- Authenticated Filebase uploads
- Create/edit album and media-record forms
- Writing to Airtable
- Provider-specific embeds for webpage URLs (e.g. YouTube or SoundCloud)
- HLS stream support where the browser needs a playback library

These are intentionally not represented as finished features until their backend and security controls exist.
